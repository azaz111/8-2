from BIB_API import drive_ls, folder_po_id , service_avtoriz, ls_files_dr_or_fold , bot
import subprocess , time
service = service_avtoriz()
service2 = service_avtoriz('v2')


if len(drive_ls(service)) == 1 :
   mud_id=drive_ls(service)[0]['id']
   mud_name=drive_ls(service)[0]['name']
else:
   print( 'НЕ пойму какого хрена вижу больше одного диска ') 
   exit()

print([eee.get('name') for eee in folder_po_id(service,mud_id,mud_id)])
nnn=input('ВВЕДИ ИМЯ ОСНОВНОЙ ПАПКИ С БЕКАПАМИ : ')




while True:

   while len(drive_ls(service)) != 1 :
      print( 'НЕ могу начать вижу больше одного диска ') 
      time.sleep(30)
   mud_id=drive_ls(service)[0]['id']
   mud_name=drive_ls(service)[0]['name']
   
   process = subprocess.Popen(['python3', 'copi_bec.py' ,mud_id ,mud_name ,nnn])
   process.wait()

   poisc_isk=False
   poisc_razn=False
   print('Начинаю цикл  поиска искомой ')
   while poisc_isk != True and poisc_razn != True:
      try:
         time.sleep(15)
         print('Пробую найти  папки для сравнения  ')
         for sps in folder_po_id(service,mud_id,mud_id):  ## Нашли клонируемую и копию
            name_vsfold = sps['name']
            if name_vsfold == nnn :
               
               iskoma=sps['id']
               print("\033[32m{}\033[0m".format(' найдена папка c бекапами :'  ) + iskoma )
               poisc_isk=True
            if name_vsfold == nnn+'-copy' :
               
               razn_fold_id = sps['id']
               print("\033[32m{}\033[0m".format(' найдена папка с копиями :'  ) + razn_fold_id )
               poisc_razn=True
      except:
         print('НЕСМОГ НАЙТИ ИСКОМУ повторю ')

   
   print('Исходных папок : '+ str(len(ls_files_dr_or_fold(iskoma,service))))
   print('Cкопированно папок : ' + str(len(ls_files_dr_or_fold(razn_fold_id,service))))


   if len(ls_files_dr_or_fold(iskoma,service)) <= len(ls_files_dr_or_fold(razn_fold_id,service)):
      print('     -----------------')
      print("\033[32m{}\033[0m".format(' ВЫПОЛНЕНО ! БЕКАП ЗАВЕРШЕН !'  ))
      print('     -----------------')
      print('Выполнено Условие бекап завершен !')
      bot('Закончил бекапить '+ nnn,[292529642])
      break
