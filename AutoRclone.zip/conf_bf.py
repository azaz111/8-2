osn_serv=0 # от
osn_lim=5 # До

start_json=0  # от
lim_json=300  # До