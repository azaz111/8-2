from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials
from time import sleep
import os , json
import subprocess
import pymysql
from sshtunnel import SSHTunnelForwarder
from BIB_API import bot
from random import choice
project_create_ops = []
current_key_dump = []
sleep_time = 30
try:
    import paramiko
except:
    os.system('pip install paramiko')
    import paramiko

key_filename='root_ssh.pem'
path='yassel'
tabl='json003'
tabl_json='yassel_json' # ПЕРЕМЕННАЯ ДЛЯ ddd.py и конфига бедфикс

server = SSHTunnelForwarder(
    ('149.248.8.216', 22),
    ssh_username='root',
    ssh_password='XUVLWMX5TEGDCHDU',
    remote_bind_address=('127.0.0.1', 3306)
)

def _generate_id(prefix='saf-'):
    chars = '-abcdefghijklmnopqrstuvwxyz1234567890'
    return prefix + ''.join(choice(chars) for _ in range(25)) + choice(chars[1:])
# Project Creation
def _create_projects(cloud, count):
    for i in range(count):
        new_proj = _generate_id()
        print(_get_projects(cloud))
        cloud.projects().create(body={'project_id': new_proj}).execute()

def json_to_baze():

    json_data=[]
    for root, dirs, files in os.walk('accounts'):
       for eww in files:
          with open('accounts/'+eww,'r') as f:
             #print(f)
             json_data.append(json.dumps(f.read()))
    server.start()

    mybd = getConnection()
    cur = mybd.cursor()
    try:
        cur.execute(f"DROP Table {tabl_json};") 
        cur.execute( f"INSERT INTO {tabl_json}(json_data) VALUES('{error}','True');" ) # Добавляем данные
    except:
        cur.execute( f"CREATE TABLE {tabl_json} (id int PRIMARY KEY AUTO_INCREMENT, json_data TEXT);" )
        for wer in json_data :
           cur.execute( f"INSERT INTO {tabl_json}(json_data) VALUES('{wer}');" ) # Добавляем данные

    cur.execute( f"SELECT * FROM {tabl_json}" ) # запросим все данные  
    rows = cur.fetchall()
    print('-------------------')
    print( 'Обновили базу  - в базе "%s" джисонов !'% len(rows))
    print('-------------------')
    mybd.commit()
    mybd.close()
    server.stop()

def write_status():

    server.start()

    mybd = getConnection()
    cur = mybd.cursor()
    try:
        cur.execute( f"UPDATE {tabl_json}_STATUS set status = 'True' WHERE name_baz = '{path}' " ) # Добавляем данные
    except:
        cur.execute( f"CREATE TABLE {tabl_json}_STATUS (name_baz TEXT, status TEXT);" )
        cur.execute( f"INSERT INTO {tabl_json}_STATUS (name_baz,status) VALUES('{path}','True');" ) # Добавляем данные

    cur.execute( f"SELECT * FROM {tabl_json}_STATUS " ) # запросим все данные  
    rows = cur.fetchall()
    print( 'Обновили Status  !')
    mybd.commit()
    mybd.close()
    server.stop()

def countdown(text='',num_of_secs=10):
   while num_of_secs:
       m, s = divmod(num_of_secs, 60)
       min_sec_format = '{:02d}:{:02d}'.format(m, s)
       print(text + min_sec_format, end='\r')
       sleep(1)
       num_of_secs -= 1 

def _get_projects(service):
    return [i['projectId'] for i in service.projects().list().execute()['projects']
            if i.get('lifecycleState', 'ACTIVE') == 'ACTIVE']

def spisok_get(pach,whot,host,password,pach_kuda=None):# Отправить  или принять файл с сервера
    username='root'
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host, username=username, key_filename=password)  

    if whot == 'get': 
        sftp = ssh.open_sftp()
        sftp.get( pach, pach_kuda )

    if whot == 'set':
        sftp = ssh.open_sftp()
        sftp.put(pach,pach_kuda)

def service_avtoriz(v2=None):# АВТОРИЗАЦИЯ  Drive API v3 по умолчанию v2 по запросу 
    SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/drive',
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/iam',
    'https://www.googleapis.com/auth/cloudplatformprojects'
    ]

    """АВТОРИЗАЦИЯ  Drive v3 API.."""
    creds = None   
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_console()
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    if v2:
        v='v2'
    else:
        v='v3'
    service = build('cloudresourcemanager', 'v1', credentials=creds)
    return service

def service_avtoriz2(v2=None):# АВТОРИЗАЦИЯ  Drive API v3 по умолчанию v2 по запросу 
    SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/drive',
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/iam',
    'https://www.googleapis.com/auth/cloudplatformprojects'
    ]

    """АВТОРИЗАЦИЯ  Drive v3 API.."""
    creds = None 
    
    if os.path.exists('token2.json'):
        creds = Credentials.from_authorized_user_file('token2.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials2.json', SCOPES)
            creds = flow.run_console()
        # Save the credentials for the next run
        with open('token2.json', 'w') as token:
            token.write(creds.to_json())
    if v2:
        v='v2'
    else:
        v='v3'
    service = build('cloudresourcemanager', 'v1', credentials=creds)
    return service

def telo():

    unique=[]
    proek_cloud = []
    
    try:
        _get_token('')
        sleep(2)
        print('Качнули токены')
        proek_cloud.append(service_avtoriz())
        print('Aвторизорвались')
    except:
        bot("Проект 1 Ошибка авторизации" , [292529642])
    try:
        _get_token('2')
        sleep(2)
        proek_cloud.append(service_avtoriz2())
    except:
        bot("Проект 2 Ошибка авторизации" , [292529642])
    
    print('000000000000')
    w=0
    print('В работе %s проекта '% len(proek_cloud))

    for cloud in proek_cloud:

        #print(_get_projects(cloud))
        w+=1
        token_mf='token.json'
        if w == 2:
            token_mf='token2.json'
        #for qqq in _get_projects(cloud):
        #   if qqq.find('saf') >-1 :
        #       cloud.projects().delete(projectId=qqq).execute()
        print('Работаем с ' + token_mf)
        print('1111111111111111111')
        
        process = subprocess.Popen(['python3', 'multifactory.py', '--create-projects', '10', '--token' , f'{token_mf}'  ])
        process.wait()

        print('2222222222222222222')
        n=0
        for qqq in _get_projects(cloud):
            if qqq.find('saf') >-1 :
                n+=1
                print('nomber ' + str(n))
                process = subprocess.Popen(['python3', 'multifactory.py', '--enable-services', qqq ,'--token' , f'{token_mf}' ])
                process.wait()
                print('333333333333333')
                process = subprocess.Popen(['python3', 'multifactory10.py', '--create-sas', qqq ,'--token' , f'{token_mf}' ])
                process.wait()
 
            while True:
                try:
                    proc=subprocess.Popen(['python3', 'multifactory10.py', '--download-keys', qqq , '--token' , f'{token_mf}' ])
                    proc.wait(timeout=25)
                    print('Завершился')
                    break
                except subprocess.TimeoutExpired:
                    proc.terminate()
                    print('Не завершился')
                    process = subprocess.Popen(['python3', 'multifactory.py', '--delete-sas', qqq ,'--token' , f'{token_mf}' ])
                    process.wait()
                    process = subprocess.Popen(['python3', 'multifactory10.py', '--create-sas', qqq ,'--token' , f'{token_mf}' ])
                    process.wait()
                    process = subprocess.Popen(['python3', 'multifactory10.py', '--download-keys', qqq , '--token' , f'{token_mf}' ])
                    process.wait()
    json_to_baze()
    print('555555555555')

def getConnection(): 
    # Вы можете изменить параметры соединения.
    connection = pymysql.connect(host='127.0.0.1', port=server.local_bind_port, user='chai_cred',
                      password='Q12w3e4003r!', database='credentals',
                      cursorclass=pymysql.cursors.DictCursor)
    return connection

def _get_token(num):
    server.start()
    mybd = getConnection()
    cur = mybd.cursor()
    cur.execute( f"SELECT * FROM {tabl} WHERE status = 'True' " ) # запросим все данные  
    rows = cur.fetchall()
    
    try:
       with open('credentials.json', 'w') as qwe:
          print(rows[0]['credentals'])
          qwe.write(rows[0]['credentals'])
       token_j2=json.loads(rows[0]['token_j'])
       with open('token%s.json' % num , 'w') as token:
           json.dump(token_j2,token)
   
       id_cred=rows[0]['id']

       print('Записались  +++ ')
       cur.execute( f"UPDATE {tabl} set status = 'False' WHERE id = {id_cred} ") # Обнавление данных
       mybd.commit()
       mybd.close()
    except:
        print('w++++++++++++++++++++++++++++++++')
        bot("НЕТ СВОБОДНЫХ КРЕДЕНТАЛСОВ" , [292529642,183787479])
    server.stop()

#json_to_baze()
while True :
    #try:
    os.system('rm -R accounts')
    os.system('mkdir accounts')
    s=0
    if s>0 :
        with open('Spisok_drive.txt', 'rb') as t:
            sp_drive=t.read().decode('utf-8').split('\n')
        for qqq in sp_drive:
          os.system(f'python3 mas_dell.py -d {qqq} --token tokenosn.pickle')
    s=s+1
    telo()
    write_status()
    #except:
    #pass
    countdown('Server name : ' + path +' time : ',24000)

