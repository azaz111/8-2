import os , time
from argparse import ArgumentParser

def transfer(dirs, json ,shag:int):
   
   unique=[]
   json_list_new=[]
   json_list=json.split('_')
   for www in json_list:
      for rrr in range(shag):
         json_list_new.append(int(www) + rrr)
   print(json_list_new)
   while True:
       dirfiles = os.listdir(dirs)
       for qqq in  dirfiles:
          if qqq not in unique and os.stat(dirs+'/'+qqq).st_size > 108650979000:
              time.sleep(5)
              n=json_list_new[0]
              print('запускаю транс  ' + qqq + ' На джисоне номер :' + str(n))
              os.system(f'screen -dmS trans{n} rclone move {dirs}/{qqq} aws32: --drive-stop-on-upload-limit --transfers 1 -P --drive-service-account-file "/root/AutoRclone/accounts/{n}.json" -v --log-file /root/rclone1.log;')
              unique.append(qqq)
              json_list_new.append(n)
              json_list_new.remove(n) 
              if len(unique) > 12:
                 unique.pop(0)
       time.sleep(30)


if __name__ == '__main__':
    parse = ArgumentParser(description=' Настройка трансфера плотов .')
    parse.add_argument('--pach', default='/disk1', help='Путь c плотами .')
    parse.add_argument('--json', '-j' , default=1 , help='Номер джисона .')
    parse.add_argument('--shag', '-s', type=int , default=4 , help='Шаг смены джисона .')
    args = parse.parse_args()
    transfer(
       dirs=args.pach,
       json=args.json,
       shag=args.shag
    )