from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os
from sys import argv
import json



s_iddrive = argv[1] # НА каком диске






def folder_po_id(delit,service):
    folder_ids = service.files().list(corpora='drive', 
                                      includeItemsFromAllDrives=True, 
                                      supportsAllDrives=True,
                                      q="mimeType = 'application/vnd.google-apps.folder'", 
                                      driveId=delit, fields="nextPageToken, files(id,name)").execute() # Список папок на диске
 
    folder_idss = folder_ids.get('files')
    folder_ids = folder_idss[0]
    #folder_id = folder_ids.get('id') # айди папки с плотами  = folder_ids.get('id') # айди папки с плотами 
    #folder_name = folder_ids.get('id') # айди папки с плотами 
    for i in folder_idss:
        folder_id = i.get('id') # айди папки с плотами  = folder_ids.get('id') # айди папки с плотами 
        folder_name = i.get('name') # айди папки с плотами 
        vcego=spisok_fails_napapke(folder_id,delit,service)
        print('id : '+ folder_id +'   Name :'+ folder_name + 'Sodershit : ' + str(len(vcego)) )
    return folder_id

def spisok_fails_napapke(fold,s_iddrive,service,colvo=None): # Список всех файлов на диске в виде айди 
    #q = f"{fold} in parents"
    #print(q)
    if colvo:
        pass
    else:
        colvo=1000000
    file_spis=[]
    page_token = None
    while True:
        response = service.files().list(spaces='drive',
                                        q=f"'{fold}' in parents",
                                        corpora='drive',
                                        includeItemsFromAllDrives=True,
                                        supportsAllDrives=True,
                                        driveId=s_iddrive,
                                        fields='nextPageToken, files(id, name)',
                                        pageToken=page_token).execute() 
    
        for file in response.get('files', []):
            # Изменение процесса
            file_spis.append(file)
            # print(file.get('name'), file.get('id'))
        page_token = response.get('nextPageToken', None)
        if page_token is None:
            break     
    return file_spis[:colvo]

def createRemoteFolder(service2, folderName, parentID = None):
    # Create a folder on Drive, returns the newely created folders ID 
    print(f'vzghu imya {folderName}')
    body = {'title': folderName,
      'mimeType': "application/vnd.google-apps.folder"
    }
    if parentID:
        body['parents'] = [{'id': parentID}]
    root_folder = service2.files().insert(supportsTeamDrives=True , body = body ).execute() 
    return root_folder['id']

def nev_json_autoriz(json_nomber,SCOPES):
   SERVICE_ACCOUNT_FILE = f'accounts/{json_nomber}.json'
   credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
   service = build('drive', 'v3', credentials=credentials)
   return service

SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]

credentials = Credentials.from_authorized_user_file('token.json', SCOPES)
service = build('drive', 'v3', credentials=credentials)
service2 = build('drive', 'v2', credentials=credentials)

isk=[]#{'kind': 'drive#teamDrive', 'id': '0AMaFUJU6ZwpVUk9PVA', 'name': '1'}, 
     #{'kind': 'drive#teamDrive', 'id': '0AK6xcKJfha_7Uk9PVA', 'name': '2'}]

try:
    folder_po_id(s_iddrive,service)
    print('vvedi folder Osnova')
    fold=input()
    print('vvedi folder Naznaceniya')
    id_foldnazna=input()
    print('Json: ')
    json_nomber = int(input())
except:
    print("нет папок")
    exit()
 


lenss1=spisok_fails_napapke(fold,s_iddrive,service)
spp1=[eee.get('name') for eee in lenss1 ]
lenss2=spisok_fails_napapke(id_foldnazna,s_iddrive,service)
spp2=[eee.get('name') for eee in lenss2 ]
#print(lenss1)
#obschie=obschie+lenss
print('naideno 1 : '+str(len(lenss1)))
print('----------------------------------------')
print('naideno 2 : '+str(len(lenss2)))
print('----------------------------------------')
list3=list(set(spp1)-set(spp2)) 
#print(list3)
print(len(list3))
file_ids=[]

for i in lenss1:
    spp0=i.get('name')
    if spp0 in list3:
        file_ids.append(i)  # Список с разницей


service = nev_json_autoriz(json_nomber,SCOPES)
index_json=2 # Шаг смены
ij=0
for i in file_ids: 
   id = i.get('id') 
   print(f'new file :{id}')
   while True:
       try:
          if ij == index_json:
             json_nomber=json_nomber+1
             if json_nomber >= 599 :
                json_nomber = 1
             # сброс счетчика + новый джисон 
             print(f"New J {json_nomber}")      
             service = nev_json_autoriz(json_nomber,SCOPES)
             ij=0
          ij=ij+1
          print('copirovanie')
          new_file = service.files().copy( fileId=id , supportsTeamDrives=True ).execute() # копируем в цикле
          new_file = new_file.get('id')
          print(f'kopia = {new_file} ')
          file = service.files().get(fileId=new_file, supportsAllDrives=True, fields='parents').execute()
          previous_parents = ",".join(file.get('parents')) 
          file = service.files().update(fileId=new_file,
                                        addParents=id_foldnazna,
                                        supportsAllDrives=True, 
                                        removeParents=previous_parents, fields='id, parents').execute()# перемещаем в бекапную папку 
          break
       except HttpError as err: 
          if err.resp.get('content-type', '').startswith('application/json'):
              reason = json.loads(err.content).get('error').get('errors')[0].get('reason')
              print(reason)
print('Vipolnenno')

# python copi_drive.py "5"  # Пример запуска 
# 1 Должен быть авторизован джисон токен в папке 
# 2 Папка acounts  в корне каталога 
# 3 Пользователи привязаны к диску 
# 4 Только одна папка для бекаппа на диске 
# 5 Проверить что корзина пустая для каждого диска