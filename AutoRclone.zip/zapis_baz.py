import os ,time, datetime , math
import requests
try:
    import paramiko
except:
    os.system('pip install paramiko')
    time.sleep(30)
    import paramiko
    
baza='ZAPISI_db.py' # указываем скрипт базы на сервере

def command_toserv(com,host,password):# Отправляем команду в терминал убунту:
    username='root'
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host, username=username, password=password)  
    result = {}
    for q in com :
        time.sleep(2)
        stdin, stdout, stderr =ssh.exec_command(f'{q}\n')
    output=""    
    try:
        rezul=stdout.read()
        output += rezul
        result[com] = output
    except:
        pass
    print(result)
    ssh.close()
    return rezul

def ipp():
    new_ip=requests.get('http://httpbin.org/ip').json()['origin']
    return new_ip

def schet_plot(puti):
   sub = ": Deleted"  
   try:
      sfa = open(puti, "r") 
      str2 = sfa.read()
      rcl2= str2.count(sub)
      sfa.close()
   except OSError:
      print(f"Nenaideno rclone2.log'")
      rcl2=0
   return rcl2

def read_txt(file_pach):
    with open(file_pach , 'r') as f:
        ddd=f.read()
        return ddd

print(ipp())

while True:
    try:
        data_list=[]
        
        t2 = os.path.getmtime('/root/chia-plotter')
        t = time.time()
        t3 = t-t2
        
        vseti = str(datetime.timedelta(seconds = int(t3))) 
        print(vseti)
        try:
            vseti = vseti.replace(' ', ':')
            vseti = vseti.replace(',', '')
        except:
            pass
    
        
        ''' Добавляем значения в список '''
        
        data_list.append(ipp()) # добавили айпишку #1
        data_list.append(vseti) # подсчитали время #2
        try:
           data_list.append(schet_plot('/root/rclone1.log')) # подсчитали количество плотов #3
        except:
           data_list.append(0) 
        
        data_list.append(t) #4
    
        try:
           data_list.append(str(int(t3/60/data_list[2]))+'-m/plot') # подсчитали количество плотов #5
        except:
           data_list.append(0) 

        try:
           data_list.append(read_txt("/root/data_p.log")[:-1]) # Читаем пароль #6
        except:
           data_list.append(0) 

        try:
           data_list.append(read_txt("/root/data_drive.log")[:-1]) # Диск #7
        except:
           data_list.append(0) 

        try:
           data_list.append(read_txt("/root/data_json.log")[:-1]) # Читаем json #8
        except:
           data_list.append(0) 

        try:
           data_list.append(read_txt("/root/baza.log")[:-1]) # baza #9
        except:
           data_list.append('default') 


        try:
            #400 Bad Request
            with open("/root/rclone1.log" , 'r') as f :
               dd_er=f.read()[-500:]
            #print(dd_er)
            if dd_er.find('400 Bad Request') > 1 :
               data_list.append('error')
            else :
               t1_peredacha = os.path.getmtime("/root/rclone1.log")
               tek = time.time()
               peredacha : int = t1_peredacha-tek
               data_list.append(str(math.ceil(peredacha))[1:]) # t.peredacha # 10
        except:
            data_list.append('None') 


        print(data_list[2]) 
        print(data_list[3])
        print(data_list[4])
        print(data_list[7])
        print(data_list[8])
        print(data_list[9])
        
        host = '149.248.8.216'
        password='XUVLWMX5TEGDCHDU'
        
    
    
        print(command_toserv([f'python3 {baza} {data_list[0]} {data_list[1]} {data_list[2]} {data_list[3]} {data_list[4]} {data_list[5]} {data_list[6]} {data_list[7]} {data_list[8]} {data_list[9]}'],host,password))
        time.sleep(360)
    except:
        print('OSHIBKA vo VREMYA CIKLA')
        time.sleep(200)