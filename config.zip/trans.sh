read int  < aknomber.txt 
echo 'OK'
case $int in
  1 | 1-1)      x=0 ; lim=15 ;;
  11 | 1-2)     x=15 ; lim=30 ;;
  2 | 2-1)      x=30 ; lim=45 ;;
  21 | 2-2)     x=45 ; lim=60 ;;
  3 | 3-1)      x=60 ; lim=75 ;;
  31 | 3-2)     x=75 ; lim=90 ;;
  4 | 4-1)      x=90 ; lim=105 ;;
  41 | 4-2)     x=105 ; lim=120 ;;
  5 | 5-1)      x=120 ; lim=135 ;;
  51 | 5-2)     x=135 ; lim=150 ;;
  6 | 6-1)      x=150 ; lim=165 ;;
  61 | 6-2)     x=165 ; lim=180 ;;
  7 | 7-1)      x=180 ; lim=195 ;;
  71 | 7-2)     x=195 ; lim=210 ;;
  8 | 8-1)      x=210 ; lim=225 ;;
  81 | 8-2)     x=225 ; lim=240 ;;
  9 | 9-1)      x=240 ; lim=255 ;;
  91 | 9-2)     x=255 ; lim=270 ;;
  10 | 10-1)    x=270 ; lim=285 ;;
 101 | 10-2)    x=285 ; lim=300 ;;
  11-1 | 11-1)  x=300 ; lim=315  ;;
  11-2 | 11-2)  x=315 ; lim=330  ;;
  12 | 12-1)    x=330 ; lim=345  ;;
  121 | 12-2)   x=345 ; lim=360 ;;
  13 | 13-1)    x=360 ; lim=375  ;;
  131 | 13-2)   x=375 ; lim=390  ;;
  14 | 14-1)    x=390 ; lim=405  ;;
  141 | 14-2)   x=405 ; lim=420 ;;
  15 | 15-1)    x=420 ; lim=435  ;;
  151 | 15-2)   x=435 ; lim=450 ;;
  16 | 16-1)    x=450 ; lim=465 ;;
  161 | 16-2)   x=465 ; lim=480 ;;
  17 | 17-1)    x=480 ; lim=495 ;;
  171 | 17-2)   x=495 ; lim=510 ;;
  18 | 18-1)    x=510 ; lim=525 ;;
  181 | 18-2)   x=525 ; lim=540 ;;
  19 | 19-1)    x=540 ; lim=555 ;;
  191 | 19-2)   x=555 ; lim=570 ;;
  20 | 20-1)    x=570 ; lim=585 ;;
  201 | 20-2)   x=585 ; lim=600 ;;
  *)              
    echo -e "Ne vveden/Ne korekten nomer AKKA \n"
    ./trans.sh
    ;;
esac


i=1
while [ $i -le 5 ]
do
x=$(( $x + 1 ))
echo "schetchekSA: $x"
pkill rclone
screen -dmS trans1 rclone move /disk4/video aws32: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/accounts/$(( $x )).json" -v --log-file /root/rclone1.log;
sleep 30
screen -dmS trans2 rclone move /disk4/video1 aws32: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/accounts/$(( $x )).json" -v --log-file /root/rclone2.log;
sleep 3600
if [ $x = $lim ]; then x=$(( $x - 15 )) ; fi
sm="$(screen -ls | grep -e 'otpravka'| tail -n1)"
ssm=${#sm}
if [ "$ssm" -gt 40 ]; then echo "Otpravka zapucshena Ok"; else  echo "Otpravki NeT - Zapuskaem" ; screen -dmS otpravka_na_serv ./otpravka.sh ; fi
done
 
